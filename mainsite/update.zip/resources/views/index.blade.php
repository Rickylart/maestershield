@extends('layouts.main')
@section('title','Index')
@section('content')
@include('layouts.banner')
    <livewire:index-page />
@endsection
